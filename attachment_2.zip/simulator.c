/* SUBMIT ONLY THIS FILE */
/* NAME: ....... */
/* UCI ID: .......*/

// only include standard libraries.
#include <stdio.h>

void simulate(double *avg_wait, int avg_wait_l, int procs, char dist){

    // YOUR CODE GOES HERE

    // start of useless code. Just delete it.
    for(int i=0; i<avg_wait_l; i++){
        avg_wait[i] = i;
    }
    printf("procs: %d\ndist: %c\n", procs, dist);
    // end of useless code
}
