void simulate(double *avg_wait, int avg_wait_l, int procs, char dist);
